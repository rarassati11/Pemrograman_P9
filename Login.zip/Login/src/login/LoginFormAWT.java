
package login;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author raras
 */
public class LoginFormAWT extends javax.swing.JFrame implements ActionListener {


Label labelTitle, labelUser, labelPass;
    TextField textUser, textPass;
    Button btnLogin;

    public LoginFormAWT() {
        setTitle("Login");
        setSize(350, 250);
        setLayout(null); 
        setLocationRelativeTo(null); 

        // Judul
        labelTitle = new Label("WELCOME TO 06TPLE004");
        labelTitle.setFont(new Font("Arial", Font.BOLD, 16));
        labelTitle.setBounds(70, 40, 220, 20);
        add(labelTitle);

        // Username
        labelUser = new Label("Username:");
        labelUser.setBounds(50, 80, 70, 20);
        add(labelUser);

        textUser = new TextField();
        textUser.setBounds(130, 80, 150, 20);
        add(textUser);

        // Password
        labelPass = new Label("Password:");
        labelPass.setBounds(50, 110, 70, 20);
        add(labelPass);

        textPass = new TextField();
        textPass.setEchoChar('*'); // Tampilkan bintang
        textPass.setBounds(130, 110, 150, 20);
        add(textPass);

        // Tombol Login
        btnLogin = new Button("Login");
        btnLogin.setBounds(130, 150, 80, 30);
        btnLogin.addActionListener(this);
        add(btnLogin);

        setVisible(true);

        // Window close
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = textUser.getText();
        String password = textPass.getText();

        if (username.equals("rara") && password.equals("12345")) {
            showMessageDialog("Login Berhasil!");
        } else {
            showMessageDialog("Username atau Password salah!");
        }
    }

    public void showMessageDialog(String message) {
        Dialog d = new Dialog(this, "Pesan", true);
        d.setLayout(new FlowLayout());
        d.add(new Label(message));
        Button ok = new Button("OK");
        ok.addActionListener(e -> d.setVisible(false));
        d.add(ok);
        d.setSize(250, 100);
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public static void main(String[] args) {
        new LoginFormAWT();
    }
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

